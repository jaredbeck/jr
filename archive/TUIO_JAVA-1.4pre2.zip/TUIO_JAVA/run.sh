#!/bin/sh
java -Dsun.java2d.opengl=true -jar TuioDemo.jar 
